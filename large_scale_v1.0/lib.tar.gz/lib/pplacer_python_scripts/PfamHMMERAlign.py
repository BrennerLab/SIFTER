'''
'''

from zope.interface import implements
from Interfaces.ThirdPartyWrapper import IThirdPartyWrapper

import os
from StringIO import StringIO

# Unofficial biopython from "kellrott" fork
# branch "hmmer_bsd" (Retrieved June 22, 2012)
import biopython_temp.AlignIO as AlignIO
from biopython_temp._Hmmer import HmmAlignCommandline, HmmPressCommandline

class PfamHMMERAlign(object):
    '''
    classdocs
    '''
    implements(IThirdPartyWrapper)
    
    expected_params = ['query_sequences_fasta_file', 'hmm_file']
    expected_executable_locations = ['hmmpress', 'hmmalign']
    
    def setup_caller(self, executable_locations, params):
        '''
        Sets up self.executable_location
        '''
        for p in self.expected_params:
            if not p in params:
                raise Exception, "PfamAlign parameter %s not provided to call."%p
        for p in self.expected_executable_locations:
            if not p in executable_locations:
                raise Exception, "PfamAlign executable %s not provided to call."%p
        
        self.executable_locations = executable_locations
        self.params = params
        
    def call(self):
        """
        Call executable with provided params.
        """
        #try:
        if not os.path.isfile(self.params['hmm_file']+".h3i"):
            call_cmd = HmmPressCommandline(cmd=self.executable_locations['hmmpress'],
                                       hmm=self.params['hmm_file'],
                                       force=False)
            self.stdout_data, self.stderr_data = call_cmd()
        call_cmd = HmmAlignCommandline(cmd=self.executable_locations['hmmalign'],
                                      hmm=self.params['hmm_file'],
                                      mapali=self.params['orig_alignment'],
                                      input=self.params['query_sequences_fasta_file'],
                                      amino=True
                                      ) 
        self.stdout_data, self.stderr_data = call_cmd()
        
        # Flag success
        self.status = 0
        #except:
        #    # Flag failure
        #    self.status = 1    
        
        
    def parse_results(self):
        """
        Parse the stored call results and return
        parsed data structure.
        Result structure is usable by ProteinInformation retriever methods.
        """
        # Expect return code to be zero
        if not(self.status == 0):
            raise Exception, "PfamAlign didn't succeed. (Return status: %i)\nStderr: %s"%(self.status, self.stderr_data)
            
        # Store matches for processing
        pfam_hmm_io = AlignIO.parse(StringIO(self.stdout_data), "stockholm")
        pfam_hmm_matches = []
        for s in pfam_hmm_io:
            pfam_hmm_matches.append(s)
        
        self.parsed_results = pfam_hmm_matches
