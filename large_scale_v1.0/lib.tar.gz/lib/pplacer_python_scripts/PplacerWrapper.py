'''
This isn't finished.
Idea is to take inputs:
	* Pfam generated alignment
	* Pfam generated tree

and to create:
	* hmm from alignment (to extend alignment using hmmalign with --mapali)
	* wrapper to pplacer/taxi to:
		* Create reference package
			* Have to remove duplicates from alignment
			  and then create an intermediate newick tree such that any
			  nodes with 0 "pendant branch length" are merged into that deduplicated
			  intermediate placeholder.
			* Want to be able to add those duplicates back onto the
			  placeholder to give a complete newick.
		* Place queries onto reference package and generate
		  newick (possibly containing duplicates as provided before "reference package" creation)
'''

from zope.interface import implements
from Interfaces.ThirdPartyWrapper import IThirdPartyWrapper

import os
import subprocess
import tempfile

from StringIO import StringIO

class PplacerWrapper(object):
	'''
	classdocs
	'''
	implements(IThirdPartyWrapper)
	
	expected_params = ['package_location',
					   'jplace_output_file',
					   'orig_alignment']
	expected_executable_locations = ['pplacer']
	
	def setup_caller(self, executable_locations={}, params={}):
		'''
		Sets up self.executable_location
		'''
		for p in self.expected_params:
			if not p in params:
				raise Exception, "PplacerWrapper parameter %s not provided to call."%p
		for p in self.expected_executable_locations:
			if not p in executable_locations:
				raise Exception, "PplacerWrapper executable %s not provided to call."%p
		
		self.executable_locations = executable_locations
		self.params = params
		
	def call(self, other_params={}):
		"""
		Call executable with provided params.
		"""
		cmd = self.executable_locations['pplacer'] + \
			  ' -c ' + self.params['package_location'] + \
			  ' -o ' + self.params['jplace_output_file'] + \
			  ' ' + self.params['orig_alignment'] #+ \
			  #' --verbosity 2'
		print cmd
		p = subprocess.Popen(cmd,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE,
							close_fds=True,
							shell=True)
		self.stdout_data, self.stderr_data = p.communicate()
		self.status = p.returncode
		
	def parse_results(self):
		"""
		Parse the stored call results and return
		parsed data structure.
		Result structure is usable by ProteinInformation retriever methods.
		"""
		# Expect return code to be zero
		if not(self.status == 0):
			raise Exception, "PplacerWrapper didn't succeed. (Return status: %i)\nStderr: %s"%(self.status, self.stderr_data)
		
		# Store matches for processing
		self.parsed_results = {'stdout': self.stdout_data,
							   'stderr': self.stderr_data}

class GuppyWrapper(object):
	'''
	classdocs
	'''
	implements(IThirdPartyWrapper)
	
	expected_params = ['jplace_file', 'tree_output_file']
	expected_executable_locations = ['guppy']
	
	def setup_caller(self, executable_locations={}, params={}):
		'''
		Sets up self.executable_location
		'''
		for p in self.expected_params:
			if not p in params:
				raise Exception, "GuppyWrapper parameter %s not provided to call."%p
		for p in self.expected_executable_locations:
			if not p in executable_locations:
				raise Exception, "GuppyWrapper executable %s not provided to call."%p
		
		self.executable_locations = executable_locations
		self.params = params
		
	def call(self, other_params={}):
		"""
		Call executable with provided params.
		"""
		#tmpf = tempfile.NamedTemporaryFile(delete=False)
		cmd = self.executable_locations['guppy'] + \
			  ' tog' + \
			  ' -o ' + self.params['tree_output_file'] + \
			  ' ' + self.params['jplace_file']
		print cmd
		p = subprocess.Popen(cmd,
							stdout=subprocess.PIPE,
							stderr=subprocess.PIPE,
							close_fds=True,
							shell=True)
		stdout_data, stderr_data = p.communicate()
		self.status = p.returncode
		
	def parse_results(self):
		"""
		Parse the stored call results and return
		parsed data structure.
		Result structure is usable by ProteinInformation retriever methods.
		"""
		# Expect return code to be zero
		if not(self.status == 0):
			raise Exception, "PplacerWrapper didn't succeed. (Return status: %i)\nStderr: %s"%(self.status, self.stderr_data)
		
		# Store matches for processing
		self.parsed_results = {'tree_output_file': self.params['tree_output_file']}
