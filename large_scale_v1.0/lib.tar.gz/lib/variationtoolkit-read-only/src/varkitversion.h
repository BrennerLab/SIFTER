#ifndef VARKIT_VERSION_H
#define VARKIT_VERSION_H

#define VARKIT_REVISION "$Revision: 83 $"

#endif
